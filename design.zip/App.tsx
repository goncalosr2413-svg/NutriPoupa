import React, { useState } from 'react';
import BottomNav from './components/BottomNav';
import Dashboard from './pages/Dashboard';
import ShoppingList from './pages/ShoppingList';
import RouteOptimization from './pages/RouteOptimization';
import NavigationMode from './pages/NavigationMode';
import Recipes from './pages/Recipes';
import Alerts from './pages/Alerts';
import Profile from './pages/Profile';
import { Onboarding } from './pages/Onboarding';
import { ViewState } from './types';

function App() {
  const [currentView, setCurrentView] = useState<ViewState>('onboarding_restrictions');

  const handleNavigate = (view: ViewState) => {
    setCurrentView(view);
    window.scrollTo(0, 0);
  };

  const renderView = () => {
    switch (currentView) {
      case 'onboarding_restrictions':
      case 'onboarding_preferences':
      case 'onboarding_goals':
        return <Onboarding step={currentView} onNavigate={handleNavigate} />;
      case 'dashboard':
        return <Dashboard onNavigate={handleNavigate} />;
      case 'shopping_list':
        return <ShoppingList onNavigate={handleNavigate} />;
      case 'route_optimization':
        return <RouteOptimization onNavigate={handleNavigate} />;
      case 'navigation_mode':
        return <NavigationMode onNavigate={handleNavigate} />;
      case 'recipes':
        return <Recipes onNavigate={handleNavigate} />;
      case 'alerts':
        return <Alerts onNavigate={handleNavigate} />;
      case 'profile':
        return <Profile onNavigate={handleNavigate} />;
      default:
        return <Dashboard onNavigate={handleNavigate} />;
    }
  };

  const showBottomNav = [
    'dashboard',
    'recipes',
    'shopping_list',
    'alerts',
    'profile',
  ].includes(currentView);

  return (
    <div className="mx-auto max-w-md bg-background-light dark:bg-background-dark min-h-screen shadow-2xl overflow-hidden relative">
      {renderView()}
      {showBottomNav && <BottomNav currentView={currentView} onNavigate={handleNavigate} />}
    </div>
  );
}

export default App;