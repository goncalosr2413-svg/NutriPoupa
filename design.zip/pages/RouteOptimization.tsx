import React from 'react';
import { ViewState } from '../types';

interface RouteOptimizationProps {
  onNavigate: (view: ViewState) => void;
}

const RouteOptimization: React.FC<RouteOptimizationProps> = ({ onNavigate }) => {
  return (
    <div className="flex flex-col h-screen bg-background-light dark:bg-background-dark text-text-main dark:text-gray-100">
      <header className="fixed top-0 w-full z-20 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-md border-b border-gray-100 dark:border-gray-800">
        <div className="max-w-md mx-auto px-4 h-14 flex items-center justify-between">
          <button onClick={() => onNavigate('dashboard')} className="p-2 -ml-2 rounded-full hover:bg-gray-100 dark:hover:bg-surface-dark transition-colors">
            <span className="material-symbols-outlined">arrow_back_ios_new</span>
          </button>
          <h1 className="text-lg font-bold text-center flex-1">Otimização de Rota</h1>
          <button className="p-2 -mr-2 rounded-full hover:bg-gray-100 dark:hover:bg-surface-dark transition-colors">
            <span className="material-symbols-outlined">more_horiz</span>
          </button>
        </div>
      </header>
      
      <main className="flex-1 flex flex-col max-w-md mx-auto w-full pt-14 relative">
        <div className="h-[45vh] w-full relative">
          <div className="absolute inset-0 w-full h-full bg-gray-200 dark:bg-gray-800 overflow-hidden">
            <img alt="Map" className="w-full h-full object-cover opacity-80 dark:opacity-40" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAtLKnbwhg6yVqt4y3WZQdVKV9dgUqGpHS3RlPuMoryMgoR1ae-puxGxNk9q_ck9Dlt-2sgrZuDCdNLfYS-DwD44SqA-tbulynaoq0YggKHjAAzW7rIAfILvCO-B8Oc42-VedNl_Dwit8mwFDdz-niEP6PcXEiXoFC8YiESqEXEERQKSJTPk5zKiQ73gtHlJHYaK1pewF9Hnnb0Lxqu9FUJ0Yb4pXyW41hAqCi0SDh5D2rRsDy1MRR1KRvAb47uPFAncCBP-4HvWmRv" />
          </div>
          
          <div className="absolute inset-0 pointer-events-none">
            {/* Pins mock */}
            <div className="absolute top-[60%] left-[20%] transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
               <div className="relative flex items-center justify-center">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                  <div className="w-4 h-4 bg-blue-500 border-2 border-white rounded-full shadow-lg z-10"></div>
               </div>
            </div>
            {/* Store 1 */}
            <div className="absolute top-[45%] left-[50%] transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
               <div className="bg-white p-1 rounded-lg shadow-lg border border-primary z-10">
                  <span className="material-symbols-outlined text-green-600">store</span>
               </div>
               <div className="w-0.5 h-3 bg-primary"></div>
            </div>
             {/* Store 2 */}
            <div className="absolute top-[30%] left-[75%] transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
               <div className="bg-white p-1 rounded-lg shadow-lg border border-red-500 z-10">
                  <span className="material-symbols-outlined text-red-500">shopping_cart</span>
               </div>
               <div className="w-0.5 h-3 bg-red-400"></div>
            </div>
          </div>
        </div>

        <div className="flex-1 bg-background-light dark:bg-background-dark -mt-6 relative rounded-t-3xl px-5 pt-6 z-10 shadow-[0_-4px_20px_-2px_rgba(0,0,0,0.1)] overflow-y-auto pb-24">
           <div className="w-12 h-1.5 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto mb-6"></div>
           <h2 className="text-xl font-bold mb-6 flex items-center justify-between">
              <span>Sua Rota de Compras</span>
              <span className="text-sm font-medium text-primary bg-primary/10 px-3 py-1 rounded-full">3 Paragens</span>
           </h2>

           <div className="relative space-y-0">
              {/* Stop 1 */}
              <div className="grid grid-cols-[32px_1fr] gap-x-4 relative group">
                 <div className="flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 z-10">
                       <span className="material-symbols-outlined text-lg">near_me</span>
                    </div>
                    <div className="w-0.5 bg-primary h-full -my-2 opacity-50"></div>
                 </div>
                 <div className="pb-8 pt-1">
                    <div className="flex justify-between items-start mb-1">
                       <h3 className="font-bold text-base">Ponto de Partida</h3>
                       <span className="text-xs font-semibold text-text-muted bg-gray-100 dark:bg-surface-dark px-2 py-1 rounded">Agora</span>
                    </div>
                    <p className="text-sm text-text-muted">Sua localização atual</p>
                 </div>
              </div>
              
              {/* Stop 2 */}
              <div className="grid grid-cols-[32px_1fr] gap-x-4 relative group">
                 <div className="flex flex-col items-center h-full">
                    <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-[#0d1b14] font-bold text-sm z-10 shadow-lg shadow-primary/30">1</div>
                    <div className="w-0.5 bg-gray-200 dark:bg-gray-700 h-full -my-2"></div>
                 </div>
                 <div className="pb-8 pt-0">
                    <div className="bg-surface-light dark:bg-surface-dark p-4 rounded-xl shadow-card border border-transparent hover:border-primary/30 transition-colors">
                       <div className="flex justify-between items-start mb-2">
                          <div>
                             <h3 className="font-bold text-lg">Lidl - Centro</h3>
                             <div className="flex items-center text-xs font-medium text-text-muted mt-1">
                                <span className="material-symbols-outlined text-[16px] mr-1">directions_car</span>
                                5 min • 2.3 km
                             </div>
                          </div>
                          <button className="text-gray-400"><span className="material-symbols-outlined">expand_more</span></button>
                       </div>
                       <div className="mt-3 pt-3 border-t border-gray-100 dark:border-gray-700/50">
                          <div className="flex items-center gap-2 mb-2">
                             <span className="material-symbols-outlined text-primary text-sm">shopping_basket</span>
                             <span className="text-sm font-semibold">3 Itens para comprar:</span>
                          </div>
                          <div className="flex flex-wrap gap-2">
                             <span className="text-xs bg-gray-100 dark:bg-gray-700/50 text-gray-600 dark:text-gray-300 px-2 py-1 rounded-md">Leite Meio Gordo</span>
                             <span className="text-xs bg-gray-100 dark:bg-gray-700/50 text-gray-600 dark:text-gray-300 px-2 py-1 rounded-md">Maçãs Gala</span>
                          </div>
                       </div>
                    </div>
                 </div>
              </div>

               {/* Stop 3 */}
               <div className="grid grid-cols-[32px_1fr] gap-x-4 relative group">
                 <div className="flex flex-col items-center h-full">
                    <div className="w-8 h-8 rounded-full bg-white dark:bg-surface-dark border-2 border-gray-300 dark:border-gray-600 flex items-center justify-center text-gray-500 font-bold text-sm z-10">2</div>
                 </div>
                 <div className="pb-4 pt-0">
                    <div className="bg-surface-light dark:bg-surface-dark p-4 rounded-xl shadow-card opacity-80">
                       <div className="flex justify-between items-center">
                          <div>
                             <h3 className="font-bold text-base">Continente - Shopping</h3>
                             <div className="flex items-center text-xs font-medium text-text-muted mt-1">
                                <span className="material-symbols-outlined text-[16px] mr-1">directions_car</span>
                                12 min • 4.1 km
                             </div>
                          </div>
                          <span className="bg-orange-100 text-orange-700 text-xs font-bold px-2 py-1 rounded">2 itens</span>
                       </div>
                    </div>
                 </div>
              </div>
           </div>

           <div className="grid grid-cols-2 gap-3 mt-4">
              <div className="bg-surface-light dark:bg-surface-dark p-4 rounded-lg border border-primary/20 flex flex-col items-center text-center shadow-sm">
                 <span className="text-xs font-medium text-text-muted uppercase tracking-wider mb-1">Tempo Total</span>
                 <div className="flex items-end gap-1">
                    <span className="text-2xl font-bold leading-none">34</span>
                    <span className="text-sm font-medium text-text-muted mb-0.5">min</span>
                 </div>
              </div>
              <div className="bg-primary/10 p-4 rounded-lg border border-primary/20 flex flex-col items-center text-center shadow-sm">
                 <span className="text-xs font-medium text-text-muted uppercase tracking-wider mb-1">Poupança Est.</span>
                 <div className="flex items-end gap-1">
                    <span className="text-2xl font-bold text-primary leading-none">€1.80</span>
                 </div>
              </div>
           </div>
        </div>

        <div className="fixed bottom-0 left-0 right-0 p-4 bg-background-light dark:bg-background-dark border-t border-gray-100 dark:border-gray-800 z-20">
           <button onClick={() => onNavigate('navigation_mode')} className="w-full bg-primary hover:bg-green-400 text-[#0d1b14] font-bold text-lg py-4 rounded-xl shadow-lg flex items-center justify-center gap-2 transform active:scale-[0.98] transition-all">
              <span className="material-symbols-outlined">navigation</span>
              Iniciar Navegação
           </button>
        </div>
      </main>
    </div>
  );
};

export default RouteOptimization;