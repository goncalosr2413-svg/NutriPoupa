import React from 'react';
import { ViewState } from '../types';

interface AlertsProps {
  onNavigate: (view: ViewState) => void;
}

const Alerts: React.FC<AlertsProps> = ({ onNavigate }) => {
  return (
    <div className="flex flex-col min-h-screen w-full bg-background-light dark:bg-background-dark pb-28">
      <header className="sticky top-0 z-20 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm px-5 py-4 flex items-center justify-between border-b border-gray-100 dark:border-white/5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#0d1b14] dark:text-white">Alertas Preditivos</h1>
          <p className="text-xs text-gray-500 dark:text-gray-400 font-medium mt-0.5">Hoje, 24 Out</p>
        </div>
        <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-white/10 transition-colors">
          <span className="material-symbols-outlined text-gray-600 dark:text-gray-300">tune</span>
        </button>
      </header>
      
      <main className="flex-1 flex flex-col gap-8 p-5 overflow-y-auto no-scrollbar">
        <section className="flex flex-col gap-4">
          <div className="flex items-center gap-2 mb-1">
             <div className="bg-orange-100 dark:bg-orange-900/30 p-1.5 rounded-lg">
                <span className="material-symbols-outlined text-orange-600 dark:text-orange-400 text-[20px]">trending_up</span>
             </div>
             <h2 className="text-lg font-bold text-[#0d1b14] dark:text-white">Próximas Subidas</h2>
          </div>
          
          {/* Alert Card 1 */}
          <div className="bg-surface-light dark:bg-surface-dark p-4 rounded-2xl shadow-card border border-gray-100 dark:border-white/5 flex flex-col gap-4">
             <div className="flex items-start gap-3">
                <div className="w-14 h-14 rounded-xl bg-gray-100 dark:bg-gray-800 overflow-hidden shrink-0 relative">
                   <img alt="Coffee" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAIQAKCdu7hgA4kuJT29ZgiKXwJ6pR99cCs5oa6XK9fooR9l69wVnPJ16wXyPUXVKyf6iFKPxMhiQcxyVxECeA7tXa7XJRWN8G3zxHVNkDKmKPzkty6k2GU_1uFJSk1UrTFwUCixW3PNSYnnJPxcxcjcp3fb0a69JgLqnH2E7hiaXepppq42xSEbaf7l0RjumKkg6EyRCAZlOnoGfyZ1ivhid7jtjHX972yOF7AMKT6gN_82WdZO74euoV4FvJ8yqmdCZHvBn2okRyY" />
                </div>
                <div className="flex-1 min-w-0">
                   <div className="flex justify-between items-start">
                      <h3 className="font-bold text-[#0d1b14] dark:text-white truncate">Café Torrado Delta</h3>
                      <span className="text-sm font-bold text-[#0d1b14] dark:text-white">€ 6.49</span>
                   </div>
                   <p className="text-sm text-gray-500 dark:text-gray-400 truncate">500g • Moagem Universal</p>
                </div>
             </div>
             
             <div className="relative h-24 w-full bg-gray-50 dark:bg-white/5 rounded-xl p-3 overflow-hidden border border-gray-100 dark:border-transparent">
                <div className="absolute top-3 left-3 flex flex-col">
                   <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Tendência</span>
                   <span className="text-orange-600 dark:text-orange-400 font-bold text-lg leading-tight">+15%</span>
                </div>
                <svg className="absolute bottom-0 right-0 w-2/3 h-full" preserveAspectRatio="none" viewBox="0 0 100 50">
                   <defs>
                      <linearGradient id="gradOrange" x1="0%" x2="0%" y1="0%" y2="100%">
                         <stop offset="0%" style={{stopColor:'#f97316', stopOpacity:0.2}}></stop>
                         <stop offset="100%" style={{stopColor:'#f97316', stopOpacity:0}}></stop>
                      </linearGradient>
                   </defs>
                   <path d="M0 45 Q 20 45 40 30 T 100 5" fill="url(#gradOrange)" stroke="none"></path>
                   <path d="M0 45 Q 20 45 40 30 T 100 5" fill="none" stroke="#f97316" strokeLinecap="round" strokeWidth="2"></path>
                   <circle cx="100" cy="5" fill="#f97316" r="3"></circle>
                </svg>
             </div>
             
             <div className="flex items-center justify-between gap-3 pt-1">
                <div className="flex items-center gap-1.5 text-orange-700 dark:text-orange-400 bg-orange-50 dark:bg-orange-900/20 px-3 py-1.5 rounded-lg text-xs font-semibold">
                   <span className="material-symbols-outlined text-[16px]">warning</span>
                   Sobe na próxima semana
                </div>
                <button className="flex-1 bg-primary hover:bg-primary-dark text-[#0d1b14] text-sm font-bold py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2">
                   <span className="material-symbols-outlined text-[18px]">add_shopping_cart</span>
                   <span className="hidden sm:inline">Adicionar</span>
                </button>
             </div>
          </div>
        </section>
        
        <section className="flex flex-col gap-4">
           <div className="flex items-center gap-2 mb-1">
              <div className="bg-primary/20 p-1.5 rounded-lg">
                 <span className="material-symbols-outlined text-green-700 dark:text-primary text-[20px]">savings</span>
              </div>
              <h2 className="text-lg font-bold text-[#0d1b14] dark:text-white">Oportunidade de Stock</h2>
           </div>
           
           <div className="bg-surface-light dark:bg-surface-dark p-4 rounded-2xl shadow-card border border-gray-100 dark:border-white/5 flex flex-col gap-4 relative overflow-hidden">
              <div className="flex items-start gap-3 relative z-10">
                 <div className="w-14 h-14 rounded-xl bg-gray-100 dark:bg-gray-800 overflow-hidden shrink-0 relative">
                    <img alt="Olive Oil" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCQ9oKV_6KDYvf2OQRVz0GN1L6x5R5iZmqF2QqFZaaxk3SR9kmjwN0gDfbal_n9X8f23FFsqbvT5W1sP-0FwHQmIZrXKrq7oFtLHrUxtZsIypjjYC0QxH8WqR4ptrnY4qvrWDNPfSG3kUJsWfKeg37mL-sAVY1UV-A7ACbgajzvb6lRQbwTgfV25cK7GcJpGeVcw1NQ00xAYCpsADW6zFLOXH6neulNY9bsOUSFmShGpVBYUxdnfdXvYv202HqFs8wE2UQC_8Ua_ZxD" />
                 </div>
                 <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start">
                       <h3 className="font-bold text-[#0d1b14] dark:text-white truncate">Azeite Virgem Extra</h3>
                       <div className="flex flex-col items-end">
                          <span className="text-sm font-bold text-green-600 dark:text-primary">€ 4.99</span>
                          <span className="text-[10px] text-gray-400 line-through">€ 6.20</span>
                       </div>
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400 truncate">Gallo • 75cl</p>
                 </div>
              </div>
              
              <div className="relative h-28 w-full bg-primary/5 dark:bg-primary/5 rounded-xl p-4 overflow-hidden border border-primary/10">
                 <div className="flex justify-between items-start mb-2 relative z-10">
                    <div className="flex flex-col">
                       <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Histórico</span>
                       <span className="text-green-700 dark:text-primary font-bold text-sm">Mínimo de 3 meses</span>
                    </div>
                 </div>
                 <svg className="absolute bottom-0 left-0 w-full h-16" preserveAspectRatio="none" viewBox="0 0 200 60">
                    <defs>
                       <linearGradient id="gradGreen" x1="0%" x2="0%" y1="0%" y2="100%">
                          <stop offset="0%" style={{stopColor:'#13ec80', stopOpacity:0.2}}></stop>
                          <stop offset="100%" style={{stopColor:'#13ec80', stopOpacity:0}}></stop>
                       </linearGradient>
                    </defs>
                    <path d="M0 10 Q 50 10 80 40 T 160 50 L 200 50 L 200 60 L 0 60 Z" fill="url(#gradGreen)" stroke="none"></path>
                    <path d="M0 10 Q 50 10 80 40 T 160 50 L 200 50" fill="none" stroke="#13ec80" strokeLinecap="round" strokeWidth="2"></path>
                    <circle className="animate-pulse" cx="180" cy="50" fill="#13ec80" r="3"></circle>
                 </svg>
              </div>
              <button className="w-full bg-primary hover:bg-primary-dark text-[#0d1b14] text-sm font-bold py-3 px-4 rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 mt-1 active:scale-[0.98]">
                 <span className="material-symbols-outlined text-[18px]">add_shopping_cart</span>
                 Comprar Agora
              </button>
           </div>
        </section>
      </main>
    </div>
  );
};

export default Alerts;