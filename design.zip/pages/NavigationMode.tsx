import React from 'react';
import { ViewState } from '../types';

interface NavigationModeProps {
  onNavigate: (view: ViewState) => void;
}

const NavigationMode: React.FC<NavigationModeProps> = ({ onNavigate }) => {
  return (
    <div className="relative w-full h-full flex flex-col justify-between bg-black overflow-hidden h-screen">
      <div className="absolute inset-0 w-full h-full z-0">
        <div 
            className="w-full h-full bg-cover bg-center" 
            style={{ 
                backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCceA-OzkAdFO1LAYlFSwA9qQV8Z4YneKVIL5x2WdArK7eDfnZKeo6LRhhbvtygi9sJ6mbXTbJ6TpDbpixftKrUAh4SSactE8y4PS9QyGd5DiZFn8f2-4TY_wFNIzz8xGAA4G2szgMJdf0T7miAypMdzUOAmLlCO2siQnUalNfriws350_uNwJ6PJBNHVnW5x1A65-3HtkNf_7dCVzwfKrAF4dz0pw86Ej_DL4n_3OEjeJ9iT-n1RFoVh811PrGiCuhnO10BaAawl3I')",
                filter: "brightness(0.6) contrast(1.2)"
            }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-transparent to-black/90 pointer-events-none"></div>
      </div>

      <div className="relative z-10 flex flex-col w-full p-4 pt-12 gap-4">
        <div className="flex justify-between items-start mb-2">
          <button onClick={() => onNavigate('dashboard')} className="flex items-center justify-center size-12 rounded-full bg-surface-dark/90 backdrop-blur-md text-white shadow-lg active:scale-95 transition-transform border border-white/10">
            <span className="material-symbols-outlined" style={{ fontSize: '24px' }}>close</span>
          </button>
          <button className="flex items-center justify-center size-12 rounded-full bg-surface-dark/90 backdrop-blur-md text-primary shadow-lg active:scale-95 transition-transform border border-white/10">
            <span className="material-symbols-outlined" style={{ fontSize: '24px' }}>volume_up</span>
          </button>
        </div>

        <div className="bg-[#11221a]/95 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-2xl flex items-center gap-5">
          <div className="flex-shrink-0 size-20 bg-primary/20 rounded-xl flex items-center justify-center border border-primary/30">
            <span className="material-symbols-outlined text-primary" style={{ fontSize: '48px', fontWeight: 700 }}>turn_right</span>
          </div>
          <div className="flex flex-col flex-1">
            <h1 className="text-white text-3xl font-extrabold tracking-tight leading-none mb-1">200m</h1>
            <p className="text-gray-300 text-lg font-medium leading-tight">Vire à direita na <span className="text-white font-bold">Rua das Flores</span></p>
          </div>
        </div>

        <div className="bg-surface-dark/90 backdrop-blur-md border border-white/5 rounded-xl p-3 px-4 shadow-lg flex items-center justify-between w-full max-w-sm mx-auto animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="size-8 rounded-full bg-white flex items-center justify-center overflow-hidden flex-shrink-0">
              <span className="text-blue-800 font-bold text-xs">Li</span>
            </div>
            <div className="flex flex-col">
              <span className="text-gray-400 text-xs font-semibold uppercase tracking-wider">Próxima Paragem</span>
              <span className="text-white text-sm font-bold">Lidl <span className="text-gray-400 font-normal mx-1">•</span> 3.2 km</span>
            </div>
          </div>
          <div className="bg-white/10 px-2 py-1 rounded text-xs text-primary font-bold font-mono">14:05</div>
        </div>
      </div>

      <div className="relative z-20 w-full mt-auto">
         <div className="absolute -top-20 right-4">
            <button className="flex items-center justify-center size-14 rounded-full bg-white text-[#11221a] shadow-xl active:scale-95 transition-transform">
               <span className="material-symbols-outlined" style={{ fontSize: '28px' }}>navigation</span>
            </button>
         </div>

         <div className="bg-[#11221a]/95 backdrop-blur-xl border-t border-white/10 rounded-t-3xl shadow-[0_-8px_30px_rgba(0,0,0,0.5)] w-full flex flex-col transition-all duration-300 ease-in-out group">
            <div className="w-full flex flex-col items-center pt-3 pb-4 px-6 cursor-pointer">
               <div className="w-12 h-1.5 bg-white/20 rounded-full mb-4 group-hover:bg-white/40 transition-colors"></div>
               <div className="w-full flex items-center justify-between">
                  <div className="flex items-center gap-3">
                     <div className="bg-primary/20 p-2 rounded-lg text-primary">
                        <span className="material-symbols-outlined">shopping_cart</span>
                     </div>
                     <div>
                        <h3 className="text-white font-bold text-lg">Lista de Compras: Lidl</h3>
                        <p className="text-primary text-sm font-medium">5 itens para recolher</p>
                     </div>
                  </div>
                  <div className="size-8 rounded-full border border-white/10 flex items-center justify-center text-gray-400">
                     <span className="material-symbols-outlined transform group-hover:-translate-y-1 transition-transform">keyboard_arrow_up</span>
                  </div>
               </div>
            </div>

            <div className="px-6 pb-8 overflow-y-auto max-h-[40vh] no-scrollbar space-y-3">
               {[
                  { name: 'Leite Meio Gordo', loc: 'Lacticínios • Corredor 2', qty: '2 un' },
                  { name: 'Ovos M (12)', loc: 'Lacticínios • Corredor 2', qty: '1 cx' },
                  { name: 'Pão de Forma Integral', loc: 'Padaria • Corredor 5', qty: '1 un' }
               ].map((item, idx) => (
                  <label key={idx} className="flex items-center gap-4 p-3 bg-surface-dark rounded-xl border border-white/5 active:bg-white/5 transition-colors cursor-pointer">
                     <div className="relative flex items-center">
                        <input className="peer size-6 rounded border-2 border-gray-500 bg-transparent text-primary focus:ring-0 focus:ring-offset-0 checked:bg-primary checked:border-primary transition-all cursor-pointer" type="checkbox"/>
                        <span className="material-symbols-outlined absolute text-[#11221a] pointer-events-none opacity-0 peer-checked:opacity-100 left-0.5 top-0.5" style={{ fontSize: '20px' }}>check</span>
                     </div>
                     <div className="flex-1">
                        <p className="text-white font-medium text-base">{item.name}</p>
                        <p className="text-gray-400 text-xs">{item.loc}</p>
                     </div>
                     <span className="text-white font-bold text-sm bg-white/10 px-2 py-1 rounded">{item.qty}</span>
                  </label>
               ))}
            </div>
         </div>
      </div>
    </div>
  );
};

export default NavigationMode;