import React, { useState } from 'react';
import { ViewState } from '../types';

interface OnboardingProps {
  step: 'onboarding_restrictions' | 'onboarding_preferences' | 'onboarding_goals';
  onNavigate: (view: ViewState) => void;
}

export const Onboarding: React.FC<OnboardingProps> = ({ step, onNavigate }) => {
  // Step 1 State
  const [restrictions, setRestrictions] = useState<string[]>(['Sem Glúten']);
  
  // Step 2 State
  const [cuisines, setCuisines] = useState<string[]>(['Italiana', 'Brasileira']);
  const [productSearch, setProductSearch] = useState('');
  const [favoriteProducts, setFavoriteProducts] = useState<string[]>([]);
  
  // Step 3 State
  const [isAthleteMode, setIsAthleteMode] = useState(false);
  const [calories, setCalories] = useState(2450);
  const [macros, setMacros] = useState({ carbs: 45, protein: 35, fat: 20 });

  const toggleRestriction = (r: string) => {
    setRestrictions(prev => prev.includes(r) ? prev.filter(i => i !== r) : [...prev, r]);
  };

  const toggleProduct = (product: string) => {
    setFavoriteProducts(prev => 
      prev.includes(product) ? prev.filter(p => p !== product) : [...prev, product]
    );
  };

  const commonIngredients = [
    "Arroz", "Feijão", "Frango", "Ovos", "Leite", "Banana", 
    "Aveia", "Azeite", "Batata", "Tomate", "Cebola", "Alho",
    "Massa", "Atum", "Iogurte", "Pão", "Queijo", "Café"
  ];

  const filteredIngredients = commonIngredients.filter(item => 
    item.toLowerCase().includes(productSearch.toLowerCase())
  );

  // --- Step 1: Restrictions ---
  if (step === 'onboarding_restrictions') {
    return (
      <div className="relative min-h-screen flex flex-col justify-between max-w-md mx-auto bg-background-light dark:bg-background-dark">
        <div className="flex-1 flex flex-col p-6">
          <div className="mb-8">
            <div className="flex justify-between items-end mb-2">
              <span className="text-sm font-semibold text-slate-800 dark:text-slate-100">Passo 1 de 3</span>
              <span className="text-xs font-medium text-primary">33%</span>
            </div>
            <div className="h-2 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
              <div className="h-full bg-primary w-1/3 rounded-full"></div>
            </div>
          </div>

          <div className="mb-8">
            <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white leading-tight mb-3">
              Quais são as suas restrições?
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-base font-medium leading-relaxed">
              Isso nos ajuda a sugerir apenas produtos seguros para você.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            {[
              { id: 'Sem Glúten', icon: 'grain' },
              { id: 'Vegano', icon: 'eco' },
              { id: 'Sem Lactose', icon: 'water_drop' },
              { id: 'Sem Nozes', icon: 'spa' },
              { id: 'Halal', icon: 'restaurant' },
              { id: 'Kosher', icon: 'verified' },
            ].map((item) => {
              const isSelected = restrictions.includes(item.id);
              return (
                <button
                  key={item.id}
                  onClick={() => toggleRestriction(item.id)}
                  className={`group relative flex flex-col items-center justify-center p-5 rounded-2xl border-2 transition-all duration-200 ${
                    isSelected 
                    ? 'border-primary bg-primary/10' 
                    : 'border-slate-200 dark:border-slate-700 bg-surface-light dark:bg-surface-dark hover:border-primary/50'
                  }`}
                >
                  {isSelected && (
                    <div className="absolute top-3 right-3 text-primary">
                      <span className="material-symbols-outlined filled text-[20px]">check_circle</span>
                    </div>
                  )}
                  <div className={`h-12 w-12 rounded-full flex items-center justify-center mb-3 shadow-sm transition-transform ${isSelected ? 'bg-white text-primary' : 'bg-slate-50 text-slate-500'}`}>
                    <span className="material-symbols-outlined text-[28px]">{item.icon}</span>
                  </div>
                  <span className={`text-base font-bold ${isSelected ? 'text-slate-900' : 'text-slate-700'} dark:text-white`}>{item.id}</span>
                </button>
              );
            })}
          </div>

          <div className="flex justify-center mb-4">
            <button className="text-sm font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white transition-colors py-2 px-4 rounded-lg">
              Nenhuma das opções acima
            </button>
          </div>
        </div>

        <div className="p-6 pt-2 bg-background-light dark:bg-background-dark sticky bottom-0 z-10 backdrop-blur-sm bg-opacity-90">
          <button 
            onClick={() => onNavigate('onboarding_preferences')}
            className="w-full bg-primary hover:bg-primary-dark active:scale-[0.98] transition-all text-[#0d1b14] text-lg font-bold py-4 rounded-xl shadow-lg shadow-primary/20 flex items-center justify-center gap-2"
          >
            <span>Próximo</span>
            <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
          </button>
        </div>
      </div>
    );
  }

  // --- Step 2: Preferences ---
  if (step === 'onboarding_preferences') {
    return (
      <div className="relative min-h-screen flex flex-col justify-between max-w-md mx-auto bg-background-light dark:bg-background-dark">
         <header className="flex flex-col gap-4 p-4 pt-6 sticky top-0 z-10 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <button onClick={() => onNavigate('onboarding_restrictions')} className="flex h-10 w-10 items-center justify-center rounded-full text-slate-900 dark:text-white hover:bg-black/5 dark:hover:bg-white/10">
              <span className="material-symbols-outlined">arrow_back</span>
            </button>
            <div className="text-sm font-semibold text-slate-500 dark:text-slate-400">Passo 2 de 3</div>
            <div className="w-10"></div>
          </div>
          <div className="flex w-full flex-row items-center gap-2 px-2">
            <div className="h-1.5 flex-1 rounded-full bg-primary"></div>
            <div className="h-1.5 flex-1 rounded-full bg-primary"></div>
            <div className="h-1.5 flex-1 rounded-full bg-slate-200 dark:bg-slate-700"></div>
          </div>
        </header>

        <main className="flex-1 flex flex-col px-6 pb-24 overflow-y-auto no-scrollbar">
          <div className="mt-2 mb-6">
            <h1 className="text-3xl font-bold leading-tight text-slate-900 dark:text-white">O que gosta de comer?</h1>
            <p className="mt-2 text-slate-500 dark:text-slate-400">Selecione suas preferências para personalizarmos sua cesta.</p>
          </div>

          <div className="mb-2 group">
            <label className="relative flex w-full items-center">
              <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none text-slate-400">
                <span className="material-symbols-outlined">add_circle</span>
              </div>
              <input 
                value={productSearch}
                onChange={(e) => setProductSearch(e.target.value)}
                className="block w-full rounded-2xl border-none bg-surface-light dark:bg-surface-dark py-4 pl-12 pr-4 text-slate-900 dark:text-white shadow-sm focus:ring-2 focus:ring-primary focus:ring-inset transition-all" 
                placeholder="Adicionar produtos favoritos..." 
                type="text"
              />
            </label>
          </div>

          <div className="mb-8 flex flex-wrap gap-2">
            {filteredIngredients.slice(0, 10).map((ing) => (
              <button 
                key={ing} 
                onClick={() => toggleProduct(ing)}
                className={`text-sm px-3 py-1.5 rounded-lg border transition-all ${
                  favoriteProducts.includes(ing)
                    ? 'bg-primary/20 border-primary text-primary-dark dark:text-primary font-bold'
                    : 'bg-surface-light dark:bg-surface-dark border-transparent text-slate-600 dark:text-slate-400'
                }`}
              >
                {ing} {favoriteProducts.includes(ing) ? '✓' : '+'}
              </button>
            ))}
          </div>

          <section className="mb-8">
            <h2 className="mb-4 text-lg font-bold text-slate-900 dark:text-white">Culinária Favorita</h2>
            <div className="flex flex-wrap gap-3">
              {[
                { name: 'Italiana', emoji: '🍝' },
                { name: 'Brasileira', emoji: '🍛' },
                { name: 'Japonesa', emoji: '🍱' },
                { name: 'Mexicana', emoji: '🌮' },
                { name: 'Mediterrânea', emoji: '🥗' },
                { name: 'Chinesa', emoji: '🥡' },
                { name: 'Indiana', emoji: '🥘' },
                { name: 'Vegetariana', emoji: '🥦' },
                { name: 'Francesa', emoji: '🥐' },
              ].map(cuisine => (
                <button 
                  key={cuisine.name}
                  onClick={() => setCuisines(prev => prev.includes(cuisine.name) ? prev.filter(c => c !== cuisine.name) : [...prev, cuisine.name])}
                  className={`flex items-center gap-2 rounded-xl border px-4 py-2.5 font-medium transition-all active:scale-95 ${
                    cuisines.includes(cuisine.name) 
                      ? 'border-primary bg-primary/10 text-slate-900 dark:text-white' 
                      : 'border-gray-200 dark:border-gray-700 bg-surface-light dark:bg-surface-dark text-slate-500 dark:text-slate-400'
                  }`}
                >
                  <span className="text-lg">{cuisine.emoji}</span>
                  <span>{cuisine.name}</span>
                  {cuisines.includes(cuisine.name) && <span className="material-symbols-outlined text-[18px] text-primary">check</span>}
                </button>
              ))}
            </div>
          </section>
        </main>

        <footer className="fixed bottom-0 w-full max-w-md pt-8 pb-6 px-6 pointer-events-none bg-gradient-to-t from-background-light dark:from-background-dark to-transparent">
          <div className="pointer-events-auto">
            <button 
              onClick={() => onNavigate('onboarding_goals')}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary hover:bg-primary-dark text-[#0d1b14] py-4 text-lg font-bold shadow-soft transition-all active:scale-[0.98]"
            >
              <span>Próximo</span>
              <span className="material-symbols-outlined font-bold">arrow_forward</span>
            </button>
          </div>
        </footer>
      </div>
    );
  }

  // --- Step 3: Goals/Macros ---
  return (
    <div className="relative min-h-screen flex flex-col justify-between max-w-md mx-auto bg-background-light dark:bg-background-dark">
      <div className="flex-none px-4 pt-4 pb-2 sticky top-0 z-10 bg-background-light dark:bg-background-dark">
        <div className="flex items-center justify-between mb-4">
          <button onClick={() => onNavigate('onboarding_preferences')} className="text-slate-900 dark:text-white flex size-10 items-center justify-center hover:bg-black/5 dark:hover:bg-white/10 rounded-full transition-colors">
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <h2 className="text-slate-900 dark:text-white text-lg font-bold">Metas e Macros</h2>
          <div className="size-10"></div>
        </div>
        <div className="flex flex-col gap-2">
          <div className="flex justify-between items-end">
            <p className="text-slate-900 dark:text-white text-sm font-semibold">Passo 3 de 3</p>
            <p className="text-primary text-xs font-bold">100%</p>
          </div>
          <div className="h-1.5 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
            <div className="h-full bg-primary rounded-full w-full"></div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col px-4 pb-24 overflow-y-auto">
        <div className="py-4">
          <h1 className="text-slate-900 dark:text-white text-3xl font-bold leading-tight mb-2">Defina os seus objetivos</h1>
          <p className="text-slate-500 dark:text-slate-400 text-base">Ajuste suas preferências nutricionais.</p>
        </div>

        <div 
          className={`flex items-center gap-4 bg-white dark:bg-surface-dark p-4 rounded-2xl shadow-sm border mb-6 transition-all duration-300 ${isAthleteMode ? 'border-primary' : 'border-slate-100 dark:border-slate-800'}`}
          onClick={() => setIsAthleteMode(!isAthleteMode)}
        >
          <div className={`flex items-center justify-center rounded-xl shrink-0 size-12 transition-colors ${isAthleteMode ? 'bg-primary text-[#0d1b14]' : 'bg-slate-100 dark:bg-white/10 text-slate-400'}`}>
            <span className="material-symbols-outlined">fitness_center</span>
          </div>
          <div className="flex-1 cursor-pointer">
            <p className="text-slate-900 dark:text-white text-base font-bold">Modo Atleta</p>
            <p className="text-slate-500 dark:text-slate-400 text-xs">Ativar contagem de calorias e macros.</p>
          </div>
          <div className="shrink-0">
             <div className={`relative flex h-7 w-12 cursor-pointer items-center rounded-full p-1 transition-all duration-200 ${isAthleteMode ? 'bg-primary justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'}`}>
                <div className="h-5 w-5 rounded-full bg-white shadow-sm"></div>
             </div>
          </div>
        </div>

        {isAthleteMode && (
          <div className="animate-fade-in space-y-8">
            <div className="flex justify-center relative">
              <div className="relative w-48 h-48 rounded-full shadow-lg flex items-center justify-center" 
                    style={{ background: `conic-gradient(#06b6d4 0% ${macros.carbs}%, #13ec80 ${macros.carbs}% ${macros.carbs + macros.protein}%, #fbbf24 ${macros.carbs + macros.protein}% 100%)` }}>
                  <div className="bg-background-light dark:bg-background-dark w-36 h-36 rounded-full flex flex-col items-center justify-center shadow-inner z-10">
                    <span className="text-slate-400 text-xs uppercase font-bold tracking-wider mb-1">Diário</span>
                    <input 
                      type="number"
                      value={calories}
                      onChange={(e) => setCalories(Number(e.target.value))}
                      className="text-slate-900 dark:text-white text-3xl font-bold tracking-tight bg-transparent text-center w-32 focus:outline-none focus:border-b-2 focus:border-primary"
                    />
                    <span className="text-slate-500 text-xs font-medium">kcal</span>
                  </div>
              </div>
              
              <div className="absolute top-0 right-4 bg-white dark:bg-surface-dark px-2 py-1 rounded-lg shadow-sm border border-slate-100 dark:border-slate-800 flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-primary"></div>
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{macros.protein}% Prot</span>
              </div>
              <div className="absolute bottom-4 left-0 bg-white dark:bg-surface-dark px-2 py-1 rounded-lg shadow-sm border border-slate-100 dark:border-slate-800 flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-[#06b6d4]"></div>
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{macros.carbs}% Carb</span>
              </div>
            </div>

            <div className="flex flex-col gap-6">
              <div className="flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-[#06b6d4]"></div>
                        <label className="text-slate-900 dark:text-white font-semibold">Carboidratos</label>
                    </div>
                    <span className="bg-[#06b6d4]/10 text-[#06b6d4] px-2 py-0.5 rounded text-sm font-bold">{macros.carbs}%</span>
                  </div>
                  <input 
                    className="w-full z-10 accent-[#06b6d4]" 
                    max="100" min="0" 
                    type="range" 
                    value={macros.carbs}
                    onChange={(e) => setMacros({...macros, carbs: Number(e.target.value)})}
                  />
              </div>

              <div className="flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-primary"></div>
                        <label className="text-slate-900 dark:text-white font-semibold">Proteínas</label>
                    </div>
                    <span className="bg-primary/10 text-green-700 dark:text-green-300 px-2 py-0.5 rounded text-sm font-bold">{macros.protein}%</span>
                  </div>
                  <input 
                    className="w-full z-10 accent-primary" 
                    max="100" min="0" 
                    type="range" 
                    value={macros.protein}
                    onChange={(e) => setMacros({...macros, protein: Number(e.target.value)})}
                  />
              </div>

              <div className="flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-[#fbbf24]"></div>
                        <label className="text-slate-900 dark:text-white font-semibold">Gorduras</label>
                    </div>
                    <span className="bg-[#fbbf24]/10 text-yellow-700 dark:text-yellow-300 px-2 py-0.5 rounded text-sm font-bold">{macros.fat}%</span>
                  </div>
                  <input 
                    className="w-full z-10 accent-[#fbbf24]" 
                    max="100" min="0" 
                    type="range" 
                    value={macros.fat}
                    onChange={(e) => setMacros({...macros, fat: Number(e.target.value)})}
                  />
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md z-20">
         <button 
           onClick={() => onNavigate('dashboard')}
           className="w-full bg-primary hover:bg-green-400 text-[#0d1b14] font-bold text-lg py-4 rounded-xl shadow-lg transition-all active:scale-[0.98] flex items-center justify-center gap-2"
         >
            <span>Concluir e Otimizar</span>
            <span className="material-symbols-outlined">rocket_launch</span>
         </button>
      </div>
    </div>
  );
};