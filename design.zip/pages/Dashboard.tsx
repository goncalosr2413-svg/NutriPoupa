import React from 'react';
import { ViewState } from '../types';

interface DashboardProps {
  onNavigate: (view: ViewState) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark min-h-screen text-text-main dark:text-gray-100 flex flex-col font-display pb-28">
      <header className="sticky top-0 z-20 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm border-b border-gray-100 dark:border-gray-800 px-5 pt-12 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-text-muted font-medium mb-0.5">Olá, João</p>
            <h1 className="text-2xl font-bold tracking-tight text-text-main dark:text-white">NutriPoupa</h1>
          </div>
          <button className="relative p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors" onClick={() => onNavigate('alerts')}>
            <span className="material-symbols-outlined text-text-main dark:text-white">notifications</span>
            <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-background-light dark:border-background-dark"></span>
          </button>
        </div>
      </header>
      
      <main className="flex-1 px-5 pt-6 flex flex-col gap-8 overflow-y-auto">
        <section className="flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-surface-light dark:bg-surface-dark rounded-2xl p-4 border border-gray-100 dark:border-gray-800 shadow-card flex flex-col justify-between h-32 relative overflow-hidden group">
              <div className="absolute right-[-20px] top-[-20px] w-20 h-20 bg-primary/10 rounded-full blur-xl group-hover:bg-primary/20 transition-all"></div>
              <div className="z-10">
                <div className="flex items-center gap-2 mb-2">
                  <span className="material-symbols-outlined text-primary text-xl">account_balance_wallet</span>
                  <p className="text-xs text-text-muted font-bold uppercase tracking-wider">Budget</p>
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-xl font-bold text-text-main dark:text-white">€ 150</span>
                  <span className="text-xs text-gray-400 font-medium">/ 400</span>
                </div>
              </div>
              <div className="w-full bg-gray-100 dark:bg-gray-700 h-1.5 rounded-full mt-auto overflow-hidden">
                <div className="bg-primary h-full rounded-full" style={{ width: '37.5%' }}></div>
              </div>
            </div>
            
            <div className="bg-surface-light dark:bg-surface-dark rounded-2xl p-4 border border-gray-100 dark:border-gray-800 shadow-card flex flex-col justify-between h-32 relative overflow-hidden group">
              <div className="absolute right-[-20px] top-[-20px] w-20 h-20 bg-blue-400/10 rounded-full blur-xl group-hover:bg-blue-400/20 transition-all"></div>
              <div className="z-10">
                <div className="flex items-center gap-2 mb-2">
                  <span className="material-symbols-outlined text-blue-500 text-xl">health_and_safety</span>
                  <p className="text-xs text-text-muted font-bold uppercase tracking-wider">Proteína</p>
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-xl font-bold text-text-main dark:text-white">85g</span>
                  <span className="text-xs text-gray-400 font-medium">/ 100g</span>
                </div>
              </div>
              <div className="w-full bg-gray-100 dark:bg-gray-700 h-1.5 rounded-full mt-auto overflow-hidden">
                <div className="bg-blue-500 h-full rounded-full" style={{ width: '85%' }}></div>
              </div>
            </div>
          </div>
        </section>

        <section className="grid grid-cols-2 gap-4">
          <button onClick={() => onNavigate('shopping_list')} className="flex flex-col items-center justify-center gap-3 p-5 bg-primary hover:bg-primary-dark text-white rounded-2xl shadow-soft transition-all active:scale-95 group">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined text-2xl">add</span>
            </div>
            <span className="font-bold text-sm text-[#0d1b14]">Nova Lista</span>
          </button>
          
          <button onClick={() => onNavigate('route_optimization')} className="flex flex-col items-center justify-center gap-3 p-5 bg-surface-light dark:bg-surface-dark border-2 border-primary/20 hover:border-primary text-text-main dark:text-white rounded-2xl shadow-sm transition-all active:scale-95 group">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined text-2xl text-primary">map</span>
            </div>
            <span className="font-bold text-sm">Otimizar Rota</span>
          </button>
        </section>

        <section className="flex flex-col gap-4">
          <h2 className="text-lg font-bold text-text-main dark:text-white">Sugestões de Otimização</h2>
          <div className="flex flex-col gap-3">
            <div className="bg-surface-light dark:bg-surface-dark rounded-xl p-4 border-l-4 border-primary shadow-sm flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="bg-green-100 dark:bg-green-900/30 p-2.5 rounded-full text-green-700 dark:text-green-400">
                  <span className="material-symbols-outlined">savings</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-text-main dark:text-white">Opção Mais Barata</p>
                  <p className="text-xs text-gray-500 mt-0.5">3 Lojas • Economia € 8,50</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg font-extrabold text-primary">€ 45,00</p>
                <span className="text-[10px] text-gray-400">Total estimado</span>
              </div>
            </div>
            
            <div className="bg-surface-light dark:bg-surface-dark rounded-xl p-4 border-l-4 border-blue-500 shadow-sm flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="bg-blue-100 dark:bg-blue-900/30 p-2.5 rounded-full text-blue-700 dark:text-blue-400">
                  <span className="material-symbols-outlined">timer</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-text-main dark:text-white">Opção Mais Perto</p>
                  <p className="text-xs text-gray-500 mt-0.5">5 min • Pão de Açúcar</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-text-main dark:text-gray-300">€ 48,50</p>
                <span className="text-[10px] text-gray-400">Total estimado</span>
              </div>
            </div>
          </div>
        </section>

        <section className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-text-main dark:text-white">Lista Atual</h2>
            <button className="text-xs font-bold text-primary hover:text-primary-dark uppercase tracking-wide">Ver lista</button>
          </div>
          <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2 snap-x">
             {[
                { name: 'Maçã Gala', price: '€ 1,75', info: '1.5kg', img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCJQIrOigaeN2O0XbvPT7Xo9xq_7Zkbc25X0arBhRiBXuhaF_jx81PvD-QNMCI22trSzCFVx4VfpGtfOCRxi911TXG81HtB4r5BdZo5uMoDEZD9tzYhks9P7PNzfyw_ZSj9abT_cQkFocJ_iUz98lmXj9YkIPvscLpn9hH4zpPHnwOYgY9Ush_7wxc-XsMiH0inlqQPW3cmAjNgJuFgJtPhmNcVT4ojjS0rYBrzrZ744TgQMIUOBC7qk9oXmea_9uOLiaxkmzdt7lee' },
                { name: 'Leite Integral', price: '€ 0,95', info: '1un', img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBxKpS7zgqUtFvO9tAOmmmyz_WE6LRWSv5eLHoEcIa_B2QfcqCE0YREhva3j0pKg9pc2Frwwm-i9XWSkwMPqji6JWJzZmvW3STtpDtkuw6q6Nq5dtaRH1PZUrN-7HOoeXtg3W7avie1Rhpufx7J4YB_DjxC9ROQmgqSHyF3d_oh27PkkmYQJd0OVNIt-gR3VwqRNm9lWT1x4D-pujWWLzk9Mwj1z_EXai9f9trl9p6Fdbtuz6DotcZH0hqeDI4aNisnogqXspHDk6pv' },
                { name: 'Pão Integral', price: '€ 1,50', info: '1un', img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCvKLXQjV1cbRdbgPJrvrGPQmlNm91grdcRWQ_YtHV4FwIX_K4jePr2xwIv2gsgOvZ3ZR466h9_HHX6QhINzPAWZpUh3IxkylHBIcb0BLpXODpsgcYw-HqAs4DsIbGjLRJsupvWKza_bREzMXiJytQtdSM8lxToY6z2cwCjPDkEbEo-SVUfOVvPLTOpPVoqZBuAEwvzq88F4jvpoHtiflOKgtonm_GBa3MNgglhu0APNv2ONu9OMGolO_O01SKYho3rFiC3ybigGbGU' }
             ].map((item, idx) => (
               <div key={idx} className="snap-start shrink-0 flex items-center gap-3 bg-surface-light dark:bg-surface-dark p-3 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm w-[200px]">
                  <div className="w-12 h-12 shrink-0 bg-gray-50 dark:bg-gray-800 rounded-lg overflow-hidden">
                    <img className="w-full h-full object-cover" src={item.img} alt={item.name} />
                  </div>
                  <div className="overflow-hidden">
                    <p className="text-sm font-bold text-text-main dark:text-white truncate">{item.name}</p>
                    <p className="text-xs text-gray-500">{item.info} • {item.price}</p>
                  </div>
               </div>
             ))}
          </div>
        </section>

        <section className="pb-8">
           <button className="w-full bg-surface-light dark:bg-surface-dark hover:bg-gray-50 dark:hover:bg-white/5 border border-dashed border-primary/50 text-text-main dark:text-white p-6 rounded-2xl flex flex-col items-center justify-center gap-3 transition-all group">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                 <span className="material-symbols-outlined text-3xl text-primary">document_scanner</span>
              </div>
              <div className="text-center">
                 <h3 className="font-bold text-lg">Scanear Talão de Compras</h3>
                 <p className="text-sm text-gray-500 dark:text-gray-400">Atualize o seu stock e despesas automaticamente</p>
              </div>
           </button>
        </section>
      </main>
    </div>
  );
};

export default Dashboard;