import React from 'react';
import { ViewState } from '../types';

interface ProfileProps {
  onNavigate: (view: ViewState) => void;
}

const Profile: React.FC<ProfileProps> = ({ onNavigate }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-slate-100 antialiased pb-28 min-h-screen">
      <header className="sticky top-0 z-10 flex items-center bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-4 justify-between border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
            <span className="material-symbols-outlined">person</span>
          </div>
          <h1 className="text-lg font-bold tracking-tight">Meu Perfil</h1>
        </div>
        <button className="flex items-center justify-center h-10 w-10 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors">
          <span className="material-symbols-outlined">settings</span>
        </button>
      </header>

      <div className="flex flex-col items-center bg-white dark:bg-surface-dark rounded-xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 m-4">
        <div className="relative">
          <div className="h-24 w-24 rounded-full border-4 border-primary/20 p-1">
            <div className="h-full w-full rounded-full bg-cover bg-center" style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDszlBtyw3WFjhSGZ7oz7meRfOPqsX24k329PvQ_becjG7XwWJydWwDn0Df2iO_OeFRYxTh0l31CsJnbfAJFQKLYJNMAWPZbPgfFTyOkTBTqU3Xob1rNRfWobYnvyCNOidFEyHuvB3Ldq0puVKgRteX3hXEdoKvYBMVAO9wTfc5KtXYPNOCX1lcS_mEERGeYR87UyKh8kqxje9c6WlJKCaxg4W9wRWKFWHYi0t6_3hsrUKD3UGfppwSrEzpF_wPIDpUqgPB1fZjaq1a')" }}></div>
          </div>
          <div className="absolute bottom-0 right-0 bg-primary h-6 w-6 rounded-full border-2 border-white dark:border-slate-900 flex items-center justify-center">
            <span className="material-symbols-outlined text-[14px] text-black font-bold">check</span>
          </div>
        </div>
        <h2 className="mt-4 text-xl font-bold">João Silva</h2>
        <p className="text-sm text-yellow-600 dark:text-yellow-400 font-bold flex items-center gap-1">
           <span className="material-symbols-outlined text-[16px] filled">military_tech</span>
           Nível ouro de NutriScore
        </p>
      </div>

      <section className="px-4 py-2">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3 px-1">Relatório Mensal</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white dark:bg-surface-dark p-4 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col items-center justify-center">
             <p className="text-xs font-medium text-slate-500 mb-3">Poupança Total</p>
             <div className="relative h-28 w-28 flex items-center justify-center p-2">
                <svg className="h-full w-full" viewBox="0 0 100 100">
                   <circle className="text-slate-100 dark:text-slate-800" cx="50" cy="50" fill="transparent" r="40" stroke="currentColor" strokeWidth="8"></circle>
                   <circle className="text-primary" cx="50" cy="50" fill="transparent" r="40" stroke="currentColor" strokeDasharray="251.2" strokeDashoffset="62.8" strokeLinecap="round" strokeWidth="8" transform="rotate(-90 50 50)"></circle>
                </svg>
                <div className="absolute text-center">
                   <span className="text-sm font-bold">€125</span>
                </div>
             </div>
             <p className="text-[10px] mt-1 text-primary font-bold">+12% vs mês ant.</p>
          </div>
          
          <div className="bg-white dark:bg-surface-dark p-4 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col items-center justify-center">
             <p className="text-xs font-medium text-slate-500 mb-3">Metas Nutri</p>
             <div className="relative h-28 w-28 flex items-center justify-center p-2">
                <svg className="h-full w-full" viewBox="0 0 100 100">
                   <circle className="text-slate-100 dark:text-slate-800" cx="50" cy="50" fill="transparent" r="40" stroke="currentColor" strokeWidth="8"></circle>
                   <circle className="text-[#10b981]" cx="50" cy="50" fill="transparent" r="40" stroke="currentColor" strokeDasharray="251.2" strokeDashoffset="37.6" strokeLinecap="round" strokeWidth="8" transform="rotate(-90 50 50)"></circle>
                </svg>
                <div className="absolute text-center">
                   <span className="text-sm font-bold">85%</span>
                </div>
             </div>
             <p className="text-[10px] mt-1 text-[#10b981] font-bold">No caminho certo!</p>
          </div>
        </div>
      </section>

      <section className="p-4">
         <div className="bg-white dark:bg-surface-dark p-5 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800">
            <div className="flex justify-between items-end mb-6">
               <div>
                  <h4 className="text-base font-bold">Tendência de Poupança</h4>
                  <p className="text-xs text-slate-500">Últimos 4 meses</p>
               </div>
               <span className="text-primary text-xs font-bold bg-primary/10 px-2 py-1 rounded">Total: €482,20</span>
            </div>
            <div className="relative h-32 px-2">
               {/* Bar Chart */}
               <div className="absolute inset-0 flex items-end justify-between gap-4 z-10">
                  {[{m:'Out', h:'40%'}, {m:'Nov', h:'65%'}, {m:'Dez', h:'55%'}, {m:'Jan', h:'90%'}].map((item, i) => (
                      <div key={item.m} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                        <div className="w-full bg-primary/20 rounded-t-lg transition-all hover:bg-primary/40" style={{ height: item.h }}></div>
                        <span className="text-[10px] font-medium text-slate-400">{item.m}</span>
                      </div>
                  ))}
               </div>
               
               {/* Line Graph Overlay */}
               <svg className="absolute inset-0 w-full h-full z-20 pointer-events-none pb-6" preserveAspectRatio="none">
                  <path 
                    d="M 12 80 L 100 40 L 190 60 L 280 10" 
                    fill="none" 
                    stroke="#10b981" 
                    strokeWidth="3" 
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                    vectorEffect="non-scaling-stroke"
                    style={{ transform: 'scaleY(0.8) translateY(20%)' }} // Approximate alignment with bars
                  />
                  {/* Points */}
                  <circle cx="5%" cy="64%" r="4" fill="#10b981" />
                  <circle cx="37%" cy="32%" r="4" fill="#10b981" />
                  <circle cx="70%" cy="48%" r="4" fill="#10b981" />
                  <circle cx="95%" cy="8%" r="4" fill="#10b981" />
               </svg>
            </div>
         </div>
      </section>

      <section className="px-4 py-4 space-y-2">
         {['Meus Dados Nutricionais', 'Histórico de Compras', 'Definições'].map((text, i) => (
           <button key={i} className="w-full flex items-center justify-between p-4 bg-white dark:bg-surface-dark rounded-xl border border-slate-100 dark:border-slate-800 active:scale-[0.98] transition-transform">
              <div className="flex items-center gap-3">
                 <div className="h-10 w-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                    <span className="material-symbols-outlined">{['analytics', 'receipt_long', 'tune'][i]}</span>
                 </div>
                 <span className="font-medium">{text}</span>
              </div>
              <span className="material-symbols-outlined text-slate-400">chevron_right</span>
           </button>
         ))}
      </section>
    </div>
  );
};

export default Profile;