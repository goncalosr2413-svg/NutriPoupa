import React, { useState } from 'react';
import { ViewState } from '../types';

interface ShoppingListProps {
  onNavigate: (view: ViewState) => void;
}

const ShoppingList: React.FC<ShoppingListProps> = ({ onNavigate }) => {
  return (
    <div className="bg-background-light dark:bg-background-dark text-text-main dark:text-white h-screen flex flex-col overflow-hidden pb-24">
      <header className="flex items-center justify-between p-4 bg-surface-light dark:bg-surface-dark shadow-sm z-10 shrink-0">
        <button onClick={() => onNavigate('dashboard')} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-white/10 transition-colors">
          <span className="material-symbols-outlined">arrow_back</span>
        </button>
        <h1 className="text-lg font-bold text-center flex-1">Lista Otimizada</h1>
        <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-white/10 transition-colors">
          <span className="material-symbols-outlined">more_vert</span>
        </button>
      </header>

      <main className="flex-1 overflow-y-auto overflow-x-hidden pb-40 px-4 scroll-smooth pt-4">
         <div className="flex justify-between items-end mb-6 mt-2">
            <div>
               <p className="text-sm text-text-muted dark:text-gray-400 font-medium">Estimativa Total</p>
               <p className="text-3xl font-bold text-text-main dark:text-white tracking-tight">€45,20</p>
            </div>
            <div className="flex -space-x-2">
               <div className="w-8 h-8 rounded-full border-2 border-white dark:border-surface-dark bg-gray-200 bg-cover" style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDAV_bUgGlpPpRCkAW9pl_9hARHBKXmhRYJM0PGEV8nmYQV9bamC4Dkro4I77FpIw4JAXvKulCYi87WGTxGVlp4um5TOOQpk75R4PDthSUqnPgGM1XLvK7WvB_SThVM8IZIBVWazBiEx-C9krvHu64ySwehK0boPd-AD6vZYrQBHrVYF-lSV-hgP2VPGyi7sU-wp2SPQWV18u-4NKvDD8raX1p0iFKetGshpPBLpAdLUqzI8wJ85phX-bP-mol59UhNCxP_FjlZPF8t')" }}></div>
               <div className="w-8 h-8 rounded-full border-2 border-white dark:border-surface-dark bg-gray-300 flex items-center justify-center text-[10px] font-bold">+2</div>
            </div>
         </div>

         {/* Store 1 */}
         <div className="mb-8">
            <div className="flex items-center gap-3 mb-4 bg-surface-light dark:bg-surface-dark p-3 rounded-xl shadow-sm border border-gray-100 dark:border-white/5">
               <div className="w-12 h-12 rounded-lg bg-gray-100 dark:bg-white/10 shrink-0 overflow-hidden relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-green-500 to-green-700 opacity-20"></div>
                  <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-green-700 dark:text-green-400">PD</div>
               </div>
               <div className="flex-1">
                  <h3 className="font-bold text-lg leading-tight">Pingo Doce</h3>
                  <p className="text-xs text-text-muted dark:text-gray-400 flex items-center gap-1">
                     <span className="material-symbols-outlined text-[14px]">location_on</span>
                     Rua Principal, 123
                  </p>
               </div>
               <div className="bg-primary/20 text-primary-dark dark:text-primary px-2 py-1 rounded text-xs font-bold">12 itens</div>
            </div>

            <div className="relative pl-2">
               {/* Aisle */}
               <div className="grid grid-cols-[32px_1fr] gap-x-4 mb-6 group">
                  <div className="flex flex-col items-center">
                     <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center text-green-600 dark:text-green-400 z-10 ring-4 ring-background-light dark:ring-background-dark">
                        <span className="material-symbols-outlined text-lg">nutrition</span>
                     </div>
                     <div className="w-0.5 bg-gray-200 dark:bg-white/10 h-full -mt-2 grow"></div>
                  </div>
                  <div className="pb-6">
                     <h4 className="font-bold text-base mb-3 sticky top-0 bg-background-light dark:bg-background-dark py-1 z-0">Hortícolas</h4>
                     <div className="bg-surface-light dark:bg-surface-dark p-3 rounded-xl shadow-sm mb-3 border border-gray-100 dark:border-white/5 flex items-center gap-3">
                        <label className="flex items-center justify-center h-6 w-6 cursor-pointer relative">
                           <input defaultChecked className="peer form-checkbox h-5 w-5 text-primary rounded border-gray-300 focus:ring-primary focus:ring-offset-0 bg-transparent" type="checkbox"/>
                        </label>
                        <div className="flex-1">
                           <div className="flex justify-between items-start">
                              <span className="text-sm font-semibold line-through text-gray-400">Maçãs Fuji (1kg)</span>
                              <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-green-100 text-green-800">A</span>
                           </div>
                           <div className="flex justify-between items-center mt-1">
                              <span className="text-xs text-gray-500 dark:text-gray-400">1 un • <span className="text-green-600 dark:text-green-400 font-medium">€1,99</span></span>
                           </div>
                        </div>
                     </div>
                     
                     <div className="bg-surface-light dark:bg-surface-dark p-3 rounded-xl shadow-sm mb-3 border border-gray-100 dark:border-white/5 flex items-center gap-3">
                        <label className="flex items-center justify-center h-6 w-6 cursor-pointer">
                           <input className="form-checkbox h-5 w-5 text-primary rounded border-gray-300 focus:ring-primary focus:ring-offset-0 bg-transparent" type="checkbox"/>
                        </label>
                        <div className="flex-1">
                           <div className="flex justify-between items-start">
                              <span className="text-sm font-semibold">Espinafres Frescos</span>
                              <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-green-100 text-green-800">A</span>
                           </div>
                           <div className="flex justify-between items-center mt-1">
                              <span className="text-xs text-gray-500 dark:text-gray-400">200g • €0,99</span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </main>

      <div className="fixed bottom-[88px] left-0 right-0 px-4 flex flex-col gap-3 justify-center z-20 pointer-events-none">
        <button 
            onClick={() => onNavigate('route_optimization')}
            className="bg-white dark:bg-surface-dark text-text-main dark:text-white border border-gray-200 dark:border-gray-700 font-bold text-base py-3 px-8 rounded-full shadow-lg flex items-center justify-center gap-2 transform transition-transform active:scale-95 pointer-events-auto w-full max-w-sm mx-auto"
        >
          <span className="material-symbols-outlined text-primary">map</span>
          <span>Ver Rota</span>
        </button>
        <button className="bg-primary hover:bg-primary-dark text-black font-bold text-base py-3 px-8 rounded-full shadow-lg flex items-center justify-center gap-3 transform transition-transform active:scale-95 pointer-events-auto w-full max-w-sm mx-auto">
          <span>Finalizar Compra</span>
          <div className="bg-black/10 rounded-full p-1">
            <span className="material-symbols-outlined text-[20px]">qr_code_scanner</span>
          </div>
        </button>
      </div>
    </div>
  );
};

export default ShoppingList;