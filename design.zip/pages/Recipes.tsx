import React, { useState } from 'react';
import { ViewState } from '../types';

interface RecipesProps {
  onNavigate: (view: ViewState) => void;
}

const Recipes: React.FC<RecipesProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'promo' | 'history'>('promo');

  const recipes = [
    {
       title: 'Salmão Grelhado com Espargos',
       tags: ['Sem Glúten', 'Low Carb'],
       image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD_oRW5sgKIYBHeoyfEvn3tuGfspZ5gXs40dfoIm18FqL_h70GYaLhtuFbfUiocqq_lzwpDAke5dwdUAislUOpBM480WgYVAYVazqcmmmgD8orgq9uCHX2fOMzf0uWWYQuDY69lrbzlxIcIkkih6c27LwxShSSlMsmnwtm7QtWNuqIuiSQjsYONTkI6KXvwzKXeIbJOk2FHZ9cnethcVOYpSj0oh_kbynI3-6Bzn0YUKM_654KTQoIzRZ7jQx3kCSovfmeh07jfKdW9',
       time: '20 min',
       difficulty: 'Fácil',
       savings: '3,50€',
       promoIngredients: [
         { name: 'Salmão Fresco', price: '8,99€', old: '12,00€' },
         { name: 'Espargos', price: '1,99€', old: '2,99€' }
       ]
    },
    {
       title: 'Risoto de Cogumelos Selvagens',
       tags: ['Italiana', 'Vegetariana'],
       image: 'https://images.unsplash.com/photo-1476124369491-e7addf5db371?q=80&w=2070&auto=format&fit=crop',
       time: '35 min',
       difficulty: 'Médio',
       savings: '2,10€',
       promoIngredients: [
         { name: 'Arroz Arbóreo', price: '1,50€', old: '2,20€' },
         { name: 'Cogumelos', price: '1,20€', old: '1,80€' }
       ]
    },
    {
       title: 'Feijoada Light com Couve',
       tags: ['Brasileira', 'Sem Glúten'],
       image: 'https://images.unsplash.com/photo-1543339308-43e59d6b73a6?q=80&w=2070&auto=format&fit=crop',
       time: '45 min',
       difficulty: 'Fácil',
       savings: '4,00€',
       promoIngredients: [
         { name: 'Feijão Preto', price: '0,80€', old: '1,10€' },
         { name: 'Couve Lombarda', price: '0,99€', old: '1,50€' }
       ]
    },
    {
       title: 'Tacos de Frango e Abacate',
       tags: ['Mexicana', 'Rápido'],
       image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?q=80&w=1980&auto=format&fit=crop',
       time: '15 min',
       difficulty: 'Muito Fácil',
       savings: '1,80€',
       promoIngredients: [
         { name: 'Peito Frango', price: '4,50€', old: '6,00€' },
         { name: 'Abacate', price: '0,99€', old: '1,99€' }
       ]
    },
    {
       title: 'Caril de Grão e Espinafres',
       tags: ['Indiana', 'Vegano'],
       image: 'https://images.unsplash.com/photo-1631515243349-e0cb75fb8d3a?q=80&w=2088&auto=format&fit=crop',
       time: '25 min',
       difficulty: 'Fácil',
       savings: '1,50€',
       promoIngredients: [
         { name: 'Grão de Bico', price: '0,60€', old: '0,90€' },
         { name: 'Espinafres', price: '1,10€', old: '1,70€' }
       ]
    }
  ];

  const previousRecipes = [
     { title: 'Lasanha de Beringela', date: '20 Out', rating: 5, image: 'https://images.unsplash.com/photo-1574868233972-1e6c0305047b?q=80&w=1974&auto=format&fit=crop' },
     { title: 'Salada César', date: '18 Out', rating: 4, image: 'https://images.unsplash.com/photo-1550304943-4f24f54ddde9?q=80&w=2070&auto=format&fit=crop' },
     { title: 'Sopa de Legumes', date: '15 Out', rating: 5, image: 'https://images.unsplash.com/photo-1547592166-23acbe346499?q=80&w=2071&auto=format&fit=crop' },
  ];

  return (
    <div className="bg-background-light dark:bg-background-dark min-h-screen flex flex-col items-center pb-24">
      <header className="flex items-center justify-between w-full px-6 pt-12 pb-4 bg-background-light dark:bg-background-dark sticky top-0 z-20">
        <h1 className="text-text-main dark:text-white text-2xl font-extrabold tracking-tight">Receitas Inteligentes</h1>
        <button className="flex items-center justify-center w-10 h-10 rounded-full bg-surface-light dark:bg-surface-dark shadow-sm text-text-main dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
          <span className="material-symbols-outlined">settings</span>
        </button>
      </header>

      <div className="w-full px-6 pb-6 sticky top-[88px] z-10 bg-background-light dark:bg-background-dark">
        <div className="flex p-1 bg-[#e7f3ed] dark:bg-[#1a3326] rounded-xl relative">
          <button 
            onClick={() => setActiveTab('promo')}
            className={`flex-1 flex items-center justify-center py-2.5 rounded-lg text-sm font-bold transition-all ${activeTab === 'promo' ? 'bg-white dark:bg-[#254232] text-primary-dark dark:text-primary shadow-sm' : 'text-text-muted'}`}
          >
               <span className="material-symbols-outlined mr-1.5 text-[18px]">sell</span>
               Promoções
          </button>
          <button 
            onClick={() => setActiveTab('history')}
            className={`flex-1 flex items-center justify-center py-2.5 rounded-lg text-sm font-bold transition-all ${activeTab === 'history' ? 'bg-white dark:bg-[#254232] text-primary-dark dark:text-primary shadow-sm' : 'text-text-muted'}`}
          >
               <span className="material-symbols-outlined mr-1.5 text-[18px]">history</span>
               Receitas Anteriores
          </button>
        </div>
      </div>

      <div className="w-full flex-1 overflow-y-auto px-6 space-y-6 pb-6">
        {activeTab === 'promo' ? (
           recipes.map((recipe, idx) => (
            <div key={idx} className="bg-surface-light dark:bg-surface-dark rounded-2xl shadow-card overflow-hidden transition-transform hover:scale-[1.01] duration-300">
              <div className="relative h-48 w-full">
                <img alt={recipe.title} className="w-full h-full object-cover" src={recipe.image} />
                <div className="absolute top-3 right-3 bg-primary text-[#0d1b14] text-xs font-bold px-3 py-1.5 rounded-full shadow-md flex items-center gap-1">
                   <span className="material-symbols-outlined text-[16px]">savings</span>
                   Poupe {recipe.savings}
                </div>
                <div className="absolute bottom-3 left-3 flex gap-2 overflow-x-auto no-scrollbar max-w-[90%]">
                   <span className="bg-black/60 backdrop-blur-md text-white text-xs font-medium px-2.5 py-1 rounded-lg flex items-center gap-1 shrink-0">
                      <span className="material-symbols-outlined text-[14px]">schedule</span> {recipe.time}
                   </span>
                   {recipe.tags.map(tag => (
                      <span key={tag} className="bg-black/60 backdrop-blur-md text-white text-xs font-medium px-2.5 py-1 rounded-lg shrink-0">
                         {tag}
                      </span>
                   ))}
                </div>
              </div>
              <div className="p-4">
                 <h3 className="text-lg font-bold text-text-main dark:text-white leading-tight mb-3">{recipe.title}</h3>
                 <div className="bg-[#f2f8f5] dark:bg-[#132a21] rounded-xl p-3 mb-4">
                    <p className="text-xs font-semibold text-text-muted dark:text-text-muted uppercase tracking-wider mb-2">Ingredientes em Promoção</p>
                    <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                       {recipe.promoIngredients.map((ing, i) => (
                         <div key={i} className="flex-shrink-0 bg-white dark:bg-[#1a3326] border border-green-100 dark:border-green-900 rounded-lg p-2 flex flex-col min-w-[100px]">
                            <span className="text-xs text-text-main dark:text-white font-medium truncate w-full">{ing.name}</span>
                            <div className="flex items-end gap-1.5 mt-1">
                               <span className="text-sm font-bold text-primary-dark dark:text-primary">{ing.price}</span>
                               <span className="text-[10px] text-gray-400 line-through mb-0.5">{ing.old}</span>
                            </div>
                         </div>
                       ))}
                    </div>
                 </div>
                 <button className="w-full h-11 bg-primary hover:bg-primary-dark text-[#0d1b14] font-bold rounded-xl flex items-center justify-center gap-2 transition-colors">
                    Ver Detalhes
                    <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
                 </button>
              </div>
            </div>
           ))
        ) : (
           <div className="space-y-4">
              {previousRecipes.map((item, idx) => (
                 <div key={idx} className="flex items-center gap-4 bg-surface-light dark:bg-surface-dark p-3 rounded-xl shadow-sm border border-gray-100 dark:border-gray-800">
                    <div className="h-16 w-16 rounded-lg overflow-hidden shrink-0">
                       <img src={item.image} alt={item.title} className="w-full h-full object-cover"/>
                    </div>
                    <div className="flex-1">
                       <h3 className="font-bold text-text-main dark:text-white">{item.title}</h3>
                       <p className="text-xs text-text-muted">Feito em {item.date}</p>
                    </div>
                    <div className="flex items-center text-yellow-500 gap-0.5">
                       <span className="font-bold text-sm">{item.rating}</span>
                       <span className="material-symbols-outlined filled text-[16px]">star</span>
                    </div>
                 </div>
              ))}
              <div className="text-center py-8">
                 <p className="text-sm text-gray-400">Isso é tudo por enquanto!</p>
              </div>
           </div>
        )}
      </div>
    </div>
  );
};

export default Recipes;