import React from 'react';
import { ViewState } from '../types';

interface BottomNavProps {
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ currentView, onNavigate }) => {
  const navItems: { view: ViewState; label: string; icon: string }[] = [
    { view: 'dashboard', label: 'Home', icon: 'home' },
    { view: 'recipes', label: 'Receitas', icon: 'restaurant_menu' },
    { view: 'shopping_list', label: 'Lista', icon: 'list_alt' },
    { view: 'alerts', label: 'Alertas', icon: 'notifications' },
    { view: 'profile', label: 'Perfil', icon: 'person' },
  ];

  const isActive = (view: ViewState) => currentView === view;

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-surface-light dark:bg-surface-dark border-t border-gray-200 dark:border-white/5 pb-safe pt-2 px-6 flex justify-between items-center z-30 pb-6 rounded-t-2xl shadow-[0_-5px_20px_rgba(0,0,0,0.05)]">
      {navItems.map((item) => (
        <button
          key={item.view}
          onClick={() => onNavigate(item.view)}
          className={`flex flex-col items-center gap-1 flex-1 p-2 transition-all duration-300 group ${
            isActive(item.view) ? 'text-primary' : 'text-gray-400 hover:text-primary'
          }`}
        >
          {isActive(item.view) ? (
            <div className="bg-primary/10 px-4 py-1 rounded-full flex flex-col items-center animate-fade-in">
              <span className={`material-symbols-outlined filled`}>
                {item.icon}
              </span>
              <span className="text-[10px] font-bold mt-0.5">{item.label}</span>
            </div>
          ) : (
            <>
              <span className="material-symbols-outlined group-hover:scale-110 transition-transform">
                {item.icon}
              </span>
              <span className="text-[10px] font-medium">{item.label}</span>
            </>
          )}
        </button>
      ))}
    </nav>
  );
};

export default BottomNav;