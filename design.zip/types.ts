export type ViewState = 
  | 'onboarding_restrictions' 
  | 'onboarding_preferences' 
  | 'onboarding_goals' 
  | 'dashboard' 
  | 'recipes' 
  | 'shopping_list' 
  | 'alerts' 
  | 'profile' 
  | 'route_optimization' 
  | 'navigation_mode'
  | 'impact_report';

export interface Recipe {
  id: string;
  title: string;
  image: string;
  time: string;
  difficulty: string;
  savings: string;
  ingredients: { name: string; price: string; oldPrice: string }[];
}

export interface ShoppingItem {
  id: string;
  name: string;
  category: string;
  quantity: string;
  checked: boolean;
  score?: 'A' | 'B' | 'C' | 'D' | 'E';
  price?: string;
}

export interface Alert {
  id: string;
  title: string;
  subtitle: string;
  price: string;
  image: string;
  trend: 'up' | 'down';
  trendValue: string;
  type: 'warning' | 'opportunity';
  chartType: 'up' | 'dip' | 'flat';
}